import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;
import 'package:speech_to_text/speech_to_text.dart' as stt;

void main() => runApp(const TranslatorApp());

class TranslatorApp extends StatelessWidget {
  const TranslatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '连续语音翻译',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2878D0)),
        useMaterial3: true,
      ),
      home: const TranslatorPage(),
    );
  }
}

class TranslatorPage extends StatefulWidget {
  const TranslatorPage({super.key});

  @override
  State<TranslatorPage> createState() => _TranslatorPageState();
}

class _TranslatorPageState extends State<TranslatorPage> {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();
  final TextEditingController _sourceController = TextEditingController();
  final TextEditingController _translationController = TextEditingController();

  bool _available = false;
  bool _running = false;
  bool _busy = false;
  bool _isSpeaking = false;
  bool _zhToEn = true;
  bool _restartQueued = false;
  String _status = '准备就绪';
  String _error = '';
  String _lastFinal = '';
  Timer? _partialDebounce;
  Timer? _restartTimer;

  String get _sourceLocale => _zhToEn ? 'zh_CN' : 'en_US';
  String get _targetLocale => _zhToEn ? 'en' : 'zh-CN';
  String get _sourceLabel => _zhToEn ? '中文' : '英文';
  String get _targetLabel => _zhToEn ? '英文' : '中文';

  @override
  void initState() {
    super.initState();
    _initialize();
    _tts.setCompletionHandler(() {
      _isSpeaking = false;
      if (mounted && _running) {
        setState(() => _status = '正在持续监听…');
        _scheduleRestart();
      }
    });
    _tts.setErrorHandler((message) {
      _isSpeaking = false;
      if (mounted) setState(() => _error = '语音播放失败：$message');
      if (_running) _scheduleRestart();
    });
  }

  Future<void> _initialize() async {
    try {
      final ok = await _speech.initialize(
        onStatus: _onSpeechStatus,
        onError: (e) {
          if (!mounted) return;
          setState(() => _error = '语音识别：${e.errorMsg}');
          if (_running && !_isSpeaking) _scheduleRestart();
        },
        debugLogging: false,
      );
      await _tts.setLanguage(_targetLocale);
      await _tts.setSpeechRate(0.48);
      await _tts.setVolume(1.0);
      if (!mounted) return;
      setState(() {
        _available = ok;
        _status = ok ? '准备就绪' : '语音识别不可用，请检查系统语音服务和权限';
      });
    } catch (e) {
      if (mounted) setState(() => _error = '初始化失败：$e');
    }
  }

  void _onSpeechStatus(String status) {
    if (!mounted) return;
    if (status == 'done' || status == 'notListening') {
      if (_running && !_isSpeaking && !_busy) _scheduleRestart();
    }
  }

  Future<void> _start() async {
    if (!_available) await _initialize();
    if (!_available) {
      setState(() => _error = '当前设备没有可用的语音识别服务。');
      return;
    }
    setState(() {
      _running = true;
      _error = '';
      _status = '正在持续监听…';
    });
    await _startListening();
  }

  Future<void> _startListening() async {
    if (!_running || _busy || _isSpeaking || _speech.isListening) return;
    _restartTimer?.cancel();
    try {
      await _speech.listen(
        onResult: _onSpeechResult,
        localeId: _sourceLocale,
        listenFor: const Duration(minutes: 1),
        pauseFor: const Duration(seconds: 3),
        listenOptions: stt.SpeechListenOptions(
          partialResults: true,
          cancelOnError: false,
          listenMode: stt.ListenMode.dictation,
          autoPunctuation: true,
        ),
      );
    } catch (e) {
      if (mounted) setState(() => _error = '无法开始监听：$e');
      _scheduleRestart();
    }
  }

  void _onSpeechResult(stt.SpeechRecognitionResult result) {
    final words = result.recognizedWords.trim();
    if (words.isEmpty || !mounted) return;
    setState(() {
      _sourceController.text = words;
      _sourceController.selection = TextSelection.collapsed(offset: words.length);
      _status = result.finalResult ? '识别完成，正在翻译…' : '正在识别并翻译…';
    });

    // Partial results update the translation display after a short pause.
    if (!result.finalResult) {
      _partialDebounce?.cancel();
      _partialDebounce = Timer(const Duration(milliseconds: 900), () {
        if (_running && !_busy && words.length >= 2) {
          _translate(words, speak: false);
        }
      });
    } else if (words != _lastFinal) {
      _lastFinal = words;
      _partialDebounce?.cancel();
      _translate(words, speak: true);
    }
  }

  Future<void> _translate(String text, {required bool speak}) async {
    if (_busy || text.trim().isEmpty) return;
    _busy = true;
    try {
      final uri = Uri.https('api.mymemory.translated.net', '/get', {
        'q': text,
        'langpair': _zhToEn ? 'zh-CN|en' : 'en|zh-CN',
      });
      final response = await http.get(uri).timeout(const Duration(seconds: 12));
      if (response.statusCode != 200) {
        throw Exception('翻译服务暂时不可用（${response.statusCode}）');
      }
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final translated = (data['responseData']?['translatedText'] ?? '').toString();
      if (translated.isEmpty) throw Exception('没有收到翻译结果');
      if (!mounted) return;
      setState(() {
        _translationController.text = translated;
        _translationController.selection =
            TextSelection.collapsed(offset: translated.length);
        _status = speak ? '翻译完成' : '正在持续监听…';
      });
      if (speak && _running) {
        // Stop listening while speaking to prevent the app hearing its own voice.
        if (_speech.isListening) await _speech.stop();
        _isSpeaking = true;
        await _tts.setLanguage(_targetLocale);
        await _tts.speak(translated);
      }
    } catch (e) {
      if (mounted) setState(() => _error = '翻译失败：$e');
    } finally {
      _busy = false;
      if (_running && !_isSpeaking) _scheduleRestart();
    }
  }

  void _scheduleRestart() {
    if (!_running || _isSpeaking || _busy || _restartQueued) return;
    _restartQueued = true;
    _restartTimer?.cancel();
    _restartTimer = Timer(const Duration(milliseconds: 500), () async {
      _restartQueued = false;
      if (_running && !_isSpeaking && !_busy) await _startListening();
    });
  }

  Future<void> _stop() async {
    setState(() {
      _running = false;
      _status = '已停止';
    });
    _restartTimer?.cancel();
    _partialDebounce?.cancel();
    await _speech.stop();
    await _tts.stop();
    _isSpeaking = false;
  }

  Future<void> _switchDirection() async {
    final wasRunning = _running;
    await _stop();
    setState(() {
      _zhToEn = !_zhToEn;
      _sourceController.clear();
      _translationController.clear();
      _lastFinal = '';
      _error = '';
      _status = '已切换为${_sourceLabel}转${_targetLabel}';
    });
    await _tts.setLanguage(_targetLocale);
    if (wasRunning) await _start();
  }

  @override
  void dispose() {
    _restartTimer?.cancel();
    _partialDebounce?.cancel();
    _sourceController.dispose();
    _translationController.dispose();
    _speech.cancel();
    _tts.stop();
    super.dispose();
  }

  Widget _languageCard(String title, TextEditingController controller,
      {bool translated = false}) {
    return Card(
      elevation: 0,
      color: translated ? const Color(0xFFEAF3FF) : Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title,
              style: TextStyle(
                  fontSize: 13,
                  color: Colors.blueGrey.shade700,
                  fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),
          ConstrainedBox(
            constraints: const BoxConstraints(minHeight: 100),
            child: TextField(
              controller: controller,
              readOnly: true,
              maxLines: null,
              decoration: const InputDecoration(
                border: InputBorder.none,
                hintText: '等待语音输入…',
                contentPadding: EdgeInsets.zero,
              ),
              style: const TextStyle(fontSize: 19, height: 1.5),
            ),
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        title: const Text('连续实时语音翻译',
            style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        backgroundColor: const Color(0xFFF5F7FA),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            Row(children: [
              Expanded(child: Text('$_sourceLabel  →  $_targetLabel',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
              OutlinedButton.icon(
                onPressed: _switchDirection,
                icon: const Icon(Icons.swap_horiz),
                label: const Text('切换方向'),
              ),
            ]),
            const SizedBox(height: 10),
            _languageCard('$_sourceLabel · 语音识别', _sourceController),
            const SizedBox(height: 8),
            _languageCard('$_targetLabel · 自动翻译并朗读', _translationController,
                translated: true),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _running ? const Color(0xFFE7F6ED) : Colors.white,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(children: [
                Icon(_running ? Icons.graphic_eq : Icons.mic_none,
                    color: _running ? Colors.green : Colors.blueGrey),
                const SizedBox(width: 10),
                Expanded(child: Text(_status,
                    style: const TextStyle(fontWeight: FontWeight.w600))),
                if (_running)
                  const SizedBox(
                    width: 16, height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
              ]),
            ),
            if (_error.isNotEmpty) ...[
              const SizedBox(height: 10),
              Text(_error, style: const TextStyle(color: Colors.red)),
            ],
            const SizedBox(height: 18),
            SizedBox(
              height: 54,
              child: FilledButton.icon(
                onPressed: _running ? null : _start,
                icon: const Icon(Icons.play_arrow),
                label: const Text('开始连续翻译',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              height: 50,
              child: OutlinedButton.icon(
                onPressed: _running ? _stop : null,
                icon: const Icon(Icons.stop),
                label: const Text('停止'),
              ),
            ),
            const SizedBox(height: 14),
            const Text(
              '使用提示：开始后会自动持续监听；识别到完整语音片段后自动翻译并朗读。翻译过程中会短暂停止收音，避免把手机自己的英文播报再次识别进去。',
              style: TextStyle(color: Colors.blueGrey, height: 1.5, fontSize: 12),
            ),
            const SizedBox(height: 6),
            const Text(
              '注意：连续监听由手机系统语音识别服务支持，系统可能因静音、网络、权限或省电策略中断。免费翻译接口有额度和稳定性限制。',
              style: TextStyle(color: Colors.blueGrey, height: 1.5, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
