# 连续实时中英语音翻译（Flutter）

这是一个 Android / iOS 共用的 Flutter 项目源码。包含连续监听、部分识别文本显示、语音片段完成后自动翻译并朗读、翻译方向切换。

## 重要说明

- 你上传的原文件只有 README 说明，没有原始 Flutter 源码。因此这是按你的要求重新搭建的项目，不是对原项目逐行修改。
- 当前交付的是**可构建的 Flutter 源码项目**，不是已签名的 Android APK 或 iOS IPA。
- 需要在安装 Flutter SDK 的电脑上构建。iOS 的 IPA 必须使用 macOS + Xcode，并配置 Apple 开发者签名。
- 语音识别使用手机系统服务；是否支持持续识别、可用语言和后台行为取决于设备与系统。
- 为避免手机把自己播出的英文再次录入，应用会在翻译朗读时暂停收音，然后自动恢复。
- 翻译使用 MyMemory 公共接口，可能限流或暂时不可用。正式长期使用建议接入有额度保障的翻译 API。

## 运行

在项目目录执行：

```bash
flutter create .
flutter pub get
flutter run
```

首次运行时允许麦克风和语音识别权限。

## Android 权限

在 `android/app/src/main/AndroidManifest.xml` 的 `<manifest>` 内、`<application>` 外添加：

```xml
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.INTERNET" />
```

## iOS 权限

在 `ios/Runner/Info.plist` 的 `<dict>` 内添加：

```xml
<key>NSMicrophoneUsageDescription</key>
<string>用于持续识别语音并进行翻译。</string>
<key>NSSpeechRecognitionUsageDescription</key>
<string>用于识别你说的中文或英文并翻译。</string>
```

在 macOS 上构建 iOS：

```bash
flutter create .
flutter pub get
cd ios
pod install
cd ..
flutter build ios
```

然后使用 Xcode 打开 `ios/Runner.xcworkspace`，配置 Team / Bundle Identifier 和签名。

## 生成 Android APK

```bash
flutter build apk --release
```

输出通常位于 `build/app/outputs/flutter-apk/app-release.apk`。


## 通过 GitHub 云端生成 Android APK（无需本机安装 Flutter）

1. 登录 GitHub，创建一个新的空仓库，例如 `continuous-voice-translator`。
2. 解压本 ZIP，把项目内所有文件（包括隐藏的 `.github` 文件夹）上传到仓库根目录。
3. 在仓库页面打开 **Actions**，选择 **Build Android APK**。
4. 点击 **Run workflow**，再点击绿色的 **Run workflow** 确认。
5. 等待运行完成并显示绿色成功标记。
6. 打开这次运行页面底部的 **Artifacts**，下载 `continuous-voice-translator-apk`。
7. 解压下载的文件，里面的 `app-release.apk` 就是安卓安装包。

首次构建可能需要几分钟。若构建失败，把 GitHub Actions 中的错误截图发给我，我可以继续帮你排查。
